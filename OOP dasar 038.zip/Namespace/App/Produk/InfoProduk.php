<?php

interface getInfoProduk
{
    public function getInfoProduk();
}