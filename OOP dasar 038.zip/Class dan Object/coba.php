<?php

class coba
{
  
    
}

$a = new coba();
$b = new coba();
$c = new coba();

var_dump($a);
var_dump($b);
var_dump($c);

?>

