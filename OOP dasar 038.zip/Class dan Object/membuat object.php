<?php

class coba
{
  
    
}

//membuat object instance dari class
$a = new coba();
$b = new coba();

?>

